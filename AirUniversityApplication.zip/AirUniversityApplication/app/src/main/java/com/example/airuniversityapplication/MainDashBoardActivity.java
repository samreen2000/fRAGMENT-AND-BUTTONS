package com.example.airuniversityapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.app.FragmentBreadCrumbs;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainDashBoardActivity extends AppCompatActivity {
    Button btn_home,btn_course,btn_finances,btn_notify;
    FragmentBreadCrumbs frg_dash;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_dash_board);

        btn_home=findViewById(R.id.btn_act_home);
        btn_course=findViewById(R.id.btn_act_courses);
        btn_finances=findViewById(R.id.btn_act_finances);
        btn_notify=findViewById(R.id.btn_act_notification);
        frg_dash=findViewById(R.id.frg_dashboard);

        HomeFragment f_home=new HomeFragment();
        FragmentTransaction transaction=getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frg_dashboard,f_home);
        transaction.commit();

        btn_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HomeFragment f_home=new HomeFragment();
                FragmentTransaction transaction=getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frg_dashboard,f_home);
                transaction.commit();
            }
        });
        btn_course.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CoursesFragment f_course=new CoursesFragment();
                FragmentTransaction transaction=getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frg_dashboard,f_course);
                transaction.commit();
            }
        });
        btn_finances.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FinanceFragment f_finance=new FinanceFragment();
                FragmentTransaction transaction=getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frg_dashboard,f_finance);
                transaction.commit();
            }
        });
        btn_notify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NotificationFragment f_notify=new NotificationFragment();
                FragmentTransaction transaction=getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frg_dashboard,f_notify);
                transaction.commit();
            }
        });
    }
}